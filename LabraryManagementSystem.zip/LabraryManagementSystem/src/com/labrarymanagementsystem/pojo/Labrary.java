package com.labrarymanagementsystem.pojo;

public class Labrary {
	
	int book_id;
	String book_type;
	String book_name;
	String book_lang;
	String book_desc;
	double book_price;
	public Labrary( String book_type, String book_name, String book_lang, String book_desc,
			double book_price) {
		super();
		this.book_id = book_id;
		this.book_type = book_type;
		this.book_name = book_name;
		this.book_lang = book_lang;
		this.book_desc = book_desc;
		this.book_price = book_price;
	}
	public int getBook_id() {
		return book_id;
	}
	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}
	public String getBook_type() {
		return book_type;
	}
	public void setBook_type(String book_type) {
		this.book_type = book_type;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public String getBook_lang() {
		return book_lang;
	}
	public void setBook_lang(String book_lang) {
		this.book_lang = book_lang;
	}
	public String getBook_desc() {
		return book_desc;
	}
	public void setBook_desc(String book_desc) {
		this.book_desc = book_desc;
	}
	public double getBook_price() {
		return book_price;
	}
	public void setBook_price(double book_price) {
		this.book_price = book_price;
	}
	@Override
	public String toString() {
		return "Labrary [book_id=" + book_id + ", book_type=" + book_type + ", book_name=" + book_name + ", book_lang="
				+ book_lang + ", book_desc=" + book_desc + ", book_price=" + book_price + "]";
	}
	public Labrary() {
		super();
	}

}
