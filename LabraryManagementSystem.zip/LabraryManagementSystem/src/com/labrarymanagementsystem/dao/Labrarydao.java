package com.labrarymanagementsystem.dao;

import java.util.List;

import com.labrarymanagementsystem.pojo.Labrary;

public interface Labrarydao {
	
	boolean Addbook(Labrary lb);
	boolean Updatebook(Labrary lb);
	boolean Deletebook(String book_name);
	Labrary searchbybookname(String book_name);
	List<Labrary>getAllRecord();
	

}
