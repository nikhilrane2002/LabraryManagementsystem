package com.labrarymanagementsystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.labrarymanagementsystem.pojo.Labrary;
import com.labrarymanagementsystem.utility.DButility;

public class Labrarydaoimpl implements Labrarydao {
	Connection con =DButility.getconnect();
	PreparedStatement ps;
	String sql;
	int row;
	Labrary lb =null;
	
	@Override
	public boolean Addbook(Labrary lb) {
		// TODO Auto-generated method stub
		
		try {
		sql="insert into labrary( book_type, book_name,book_lang,book_desc,book_price)values (?,?,?,?,?)";
		
			ps=con.prepareStatement(sql);
			ps.setString(1, lb.getBook_type());
			ps.setString(2, lb.getBook_name());
			ps.setString(3, lb.getBook_lang());
			ps.setString(4, lb.getBook_desc());
			ps.setDouble(5, lb.getBook_price());
			
			row=ps.executeUpdate();
			if(row >0) {
				return true;
			}else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
						return false;
	}

	@Override
	public boolean Updatebook(Labrary lb) {
		sql="update labrary set book_type =?, book_name=? ,book_lang=? ,book_desc=? ,book_price=? where book_id=? ";
		try {
			ps=con.prepareStatement(sql);
		ps.setInt(6, lb.getBook_id());
			ps.setString(1, lb.getBook_type());
			ps.setString(2, lb.getBook_name());
			ps.setString(3, lb.getBook_lang());
			ps.setString(4, lb.getBook_desc());
			ps.setDouble(5, lb.getBook_price());
			
			row=ps.executeUpdate();
			if(row >0) {
				return true;
			}else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		
		return false;
	}

	@Override
	public boolean Deletebook(String book_name) {
	 sql="delete from labrary  where book_name=?";
	 try {
		ps=con.prepareStatement(sql);
		ps.setString(1, book_name);
		row=ps.executeUpdate();
		if(row>0) {
			return true;
		}else {
			return false;
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return false;
	}

	@Override
	public Labrary searchbybookname(String book_name) {
		con = DButility.getconnect();
		try {
		sql="select * from labrary where book_name=?";
	
			ps=con.prepareStatement(sql);
			ps.setString(1, book_name);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				lb= new Labrary();
				lb.setBook_id(rs.getInt("book_id"));
				lb.setBook_type(rs.getString("book_type"));
				lb.setBook_name(rs.getString("book_name"));
				lb.setBook_lang(rs.getString("book_lang"));
				lb.setBook_desc(rs.getString("book_desc"));
				lb.setBook_price(rs.getDouble("book_price"));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lb;
	}

	@Override
	public List<Labrary> getAllRecord() {
	 con =DButility.getconnect();
	 List<Labrary>alist= new ArrayList<>();
	 sql ="select * from labrary";
	 try {
		ps=con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		
		
		while(rs.next()) {
			Labrary lb = new Labrary();
			lb.setBook_id(rs.getInt("book_id"));
			lb.setBook_type(rs.getString("book_type"));
			lb.setBook_name(rs.getString("book_name"));
			lb.setBook_lang(rs.getString("book_lang"));
			lb.setBook_desc(rs.getString("book_desc"));
			lb.setBook_price(rs.getDouble("book_price"));
			alist.add(lb);
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
			 
		return alist;
	}

}
