package com.labrarymanagementsystem.test;

import java.sql.Connection;

import com.labrarymanagementsystem.utility.DButility;

public class Connectiontest {
	public static void main(String[] args) {
		Connection con = DButility.getconnect();
		
		if(con!=null) {
			System.out.println("success");
		}else {
			System.out.println("fail");
		}
	}

}
