package com.labrarymanagementsystem.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.labrarymanagementsystem.dao.Labrarydaoimpl;
import com.labrarymanagementsystem.pojo.Labrary;

public class Labrarytest {
	public static void main(String[] args) throws IOException {
		int book_id, choice =0;
		String book_type;
		String book_name;
		String book_lang;
		String book_desc;
		double book_price;
	Labrarydaoimpl impl = new Labrarydaoimpl();
		InputStreamReader str = new InputStreamReader(System.in);
		 BufferedReader bf = new BufferedReader(str);
		 Scanner sc = new  Scanner(System.in);
		 
		 while(true) {
		 System.out.println("1.add food  2. update food  3.delete food  4.search by id   5.aget all food");
		 System.out.println("**********Enter Your Choice *************");
		 choice= sc.nextInt();
		 
		 switch(choice) {
		 case 1:
			 System.out.println("=============Add Book===================");
			 System.out.println("enter your book type");
				book_type=bf.readLine();
				System.out.println(" enter your book name");
				book_name =bf.readLine();
				System.out.println(" enter your book language");
				book_lang = bf.readLine();
				System.out.println(" enter your book description");
			book_desc = bf.readLine();
				System.out.println(" enter your price");
				book_price= sc.nextDouble();
				Labrary lb =new Labrary( book_type, book_name, book_lang, book_desc, book_price);
				boolean b = impl.Addbook(lb);
				if(b) {
					System.out.println("add book sussecfully");
				
		 }else {
			System.out.println("fail to add book");
		}
			 break;
			 
		 case 2:
			 System.out.println("=============Update Book===================");
			 System.out.println(" enter the book_id that want to update");
			 book_id=sc.nextInt();
			 System.out.println("enter your  updated book type");
				book_type=bf.readLine();
				System.out.println(" enter your  updated book name");
				book_name =bf.readLine();
				System.out.println(" enter your updated book language");
				book_lang = bf.readLine();
				System.out.println(" enter your  updated book description");
			book_desc = bf.readLine();
				System.out.println(" enter your updated price");
				book_price= sc.nextDouble();
				Labrary lb1= new Labrary(book_type, book_name, book_lang, book_desc, book_price);
			 lb1.setBook_id(book_id);
			 boolean b1= impl.Updatebook(lb1);
			 if(b1) {
				 System.out.println("updated successfull");
			 }else {
				 System.out.println(" fail to update");
			 }
			 break;
			 
		 case 3:
			 System.out.println("=============Delete Book===================");
			  System.out.println(" enter the book name that want to delete");
			  book_name =bf.readLine();
			  boolean b2 = impl.Deletebook(book_name);
			  if(b2) {
				  System.out.println("delete book");
			  }else {
				  System.out.println("fail to delete");
			  }
			  break;
		 
		 case 4:
			 System.out.println("=============Search By Name===================");
			 System.out.println(" enter the  book name that you want");
			 book_name =bf.readLine();
			 Labrary lb3 =impl.searchbybookname(book_name);
			 if(lb3!=null) {
				 System.out.println(lb3);
			 }else {
				 System.out.println("record not found");
			 }
		 case  5:
			 System.out.println("=============All Book===================");
			 List<Labrary>aList= impl.getAllRecord();
			 Iterator<Labrary>it=aList.iterator();
			 while(it.hasNext()) {
				 System.out.println(it.next());
			 }
			 break;
		 
	}
		 } 
		 }

	}


