/**
 * 
 */
/**
 * @author nikhi
 *
 */
module LabraryManagementSystem {
	requires java.sql;
}